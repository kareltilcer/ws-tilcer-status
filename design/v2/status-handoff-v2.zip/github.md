repo: kareltilcer/ws-tilcer-status
branch: main
path: handoff/v2

## Last sync
date: 2026-08-01T15:35:00Z

### Updated in this project
- Synced the design to the **v2 handoff** (OpenAPI 0.2.0) and cleared review round-1 revisions.
- Rebuilt uptime against `GET /api/sites/{id}/uptime` `buckets[]`: gap buckets (`ok_pct: null`) render as a distinct hatched "no data" state, plus a strip legend and the endpoint's real p50/p95.
- Added the **monitoring-off** affordance (`uptime_pct: null` + `monitor_enabled: false`) on board cards and the site header — neutral, never red.
- Added confirmation + toast patterns: Delete (cascade warning) and Rotate-key (immediate-invalidation) confirm dialogs, rotate reusing the show-once key modal, and toasts for save/resolve/ignore.
- Added the responsive/mobile treatment (top-bar + slide-in drawer, single-column board, stacked blocks) behind a Desktop/Mobile viewport toggle.
- Delivered the two owed screens: **Accessibility** (measured AA contrast table with fixes + focus-visible + non-color cues) and **Redline** (tokens, type/spacing scales, breakpoints, component contracts). Split AA `-text` tokens from fill tokens to fix all 7 contrast failures.

## Screen map
| Project screen | Built from (source) |
|---|---|
| Status.dc.html — all screens/states | ws-tilcer-status@main handoff/v2/HANDOFF-design.md §12, HANDOFF-engineering.md, openapi.yaml (UptimeSummary, UptimeBucket, SiteSummary) |
| Uptime strip + monitoring-off | openapi.yaml `/api/sites/{id}/uptime`, `SiteSummary.uptime_pct` / `monitor_enabled` |
| Accessibility + Redline screens | handoff/v2 §9–10 deliverables (design:accessibility-review, design:design-handoff) |
| Design tokens / shell / components | ws-tilcer-home@main frontend design system (dark-default oklch, Hanken Grotesk + IBM Plex Mono) |

## Sync history
- 2026-08-01T10:30:00Z — v1 handoff: produced the full hi-fi design (5 screens + legend, all states, status color system, show-once key modal) from the spec-only handoff/v1 folder.

## Notes
- ws-tilcer-status contains only the design + engineering handoff and the OpenAPI contract; there is no frontend to recreate. The design is produced from those specs.
- Fleet look-and-feel is defined in ws-tilcer-home (the shipped sibling); status matches it. Language: English microcopy per the handoff.
